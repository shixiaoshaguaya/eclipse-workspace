package cn.lmu.bookstore.dao;

import java.util.List;

import cn.lmu.bookstore.pojo.Category;

public interface CategoryMapper {
	public List<Category> getCategoryList();
}
