package cn.lmu.bookstore.service;

import java.util.List;

import cn.lmu.bookstore.pojo.Category;

public interface CategoryService {

	public List<Category> getCategoryList();

}
